import SwiftUI

struct ShoppingCartView: View {
    @Environment(\.dismiss) private var dismiss
    let library: Library
    @State private var error: String?

    private var items: [Capture] {
        library.items.filter { ($0.cartQuantity ?? 0) > 0 }
    }

    var body: some View {
        NavigationStack {
            Group {
                if items.isEmpty {
                    ContentUnavailableView("购物车是空的", systemImage: "cart",
                                           description: Text("在商品详情中点「加入购物车」。"))
                } else {
                    List(items) { item in
                        let product = item.extraction.product
                        let quantity = item.cartQuantity ?? 1
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 12) {
                                if let thumbnail = library.thumbnail(item.id) {
                                    Image(uiImage: thumbnail)
                                        .resizable().scaledToFill()
                                        .frame(width: 60, height: 60)
                                        .clipShape(.rect(cornerRadius: 12))
                                        .accessibilityHidden(true)
                                }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(product?.name ?? item.extraction.title).font(.headline)
                                    if let price = product?.price { Text(price).foregroundStyle(.secondary) }
                                    if let merchant = product?.merchant { Text(merchant).font(.caption).foregroundStyle(.secondary) }
                                }
                            }
                            Stepper("数量 \(quantity)", value: Binding(
                                get: { quantity },
                                set: { update(item, quantity: $0) }
                            ), in: 1...99)
                            if let url = product?.webURL {
                                Link("打开商品链接", destination: url)
                            }
                        }
                        .padding(.vertical, 4)
                        .swipeActions {
                            Button("移除", role: .destructive) { update(item, quantity: nil) }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("购物车")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } }
            }
            .alert("购物车", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("好", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
    }

    private func update(_ item: Capture, quantity: Int?) {
        var updated = item
        updated.cartQuantity = quantity
        do { try library.save(updated) }
        catch { self.error = error.localizedDescription }
    }
}
