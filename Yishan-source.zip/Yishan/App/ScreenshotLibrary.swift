import Photos
import Observation

@Observable final class ScreenshotObserver: NSObject, PHPhotoLibraryChangeObserver {
    private(set) var revision = 0
    @ObservationIgnored private var registered = false

    func setEnabled(_ enabled: Bool) {
        guard registered != enabled else { return }
        registered = enabled
        if enabled {
            PHPhotoLibrary.shared().register(self)
        } else {
            PHPhotoLibrary.shared().unregisterChangeObserver(self)
        }
    }

    deinit {
        if registered { PHPhotoLibrary.shared().unregisterChangeObserver(self) }
    }

    func photoLibraryDidChange(_ changeInstance: PHChange) {
        DispatchQueue.main.async { self.revision += 1 }
    }

    static func screenshots(since date: Date) -> [PHAsset] {
        let access = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        guard access == .authorized || access == .limited else { return [] }
        let options = PHFetchOptions()
        options.predicate = NSPredicate(
            format: "creationDate >= %@ AND (mediaSubtype & %d) != 0",
            date as NSDate, PHAssetMediaSubtype.photoScreenshot.rawValue
        )
        options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
        let matches = PHAsset.fetchAssets(with: .image, options: options)
        return (0..<matches.count).map { matches.object(at: $0) }
    }

    static func data(for asset: PHAsset) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            let options = PHImageRequestOptions()
            options.version = .original
            options.deliveryMode = .highQualityFormat
            options.isNetworkAccessAllowed = true
            PHImageManager.default().requestImageDataAndOrientation(for: asset, options: options) { data, _, _, info in
                if let data {
                    continuation.resume(returning: data)
                } else {
                    continuation.resume(throwing: (info?[PHImageErrorKey] as? Error)
                        ?? FlashError.message("无法读取相册截图"))
                }
            }
        }
    }
}
