import Foundation

enum VisionRoute: String, CaseIterable, Identifiable {
    case teamo
    case bailianFlash
    case bailianMax

    var id: String { rawValue }
    var isBailian: Bool { self != .teamo }

    var model: String {
        switch self {
        case .teamo, .bailianFlash: "qwen3.8-flash"
        case .bailianMax: "qwen4-max"
        }
    }

    var label: String {
        switch self {
        case .teamo: "Teamo · 千问 3.8 Flash"
        case .bailianFlash: "百炼 · 千问 3.8 Flash"
        case .bailianMax: "百炼 · 千问 4 Max"
        }
    }

    static var current: Self {
        UserDefaults.standard.string(forKey: "visionRoute").flatMap(Self.init(rawValue:)) ?? .teamo
    }

    func endpoint(workspace: String) -> URL? {
        let host: String
        if !isBailian {
            host = "api.teamorouter.com"
        } else if workspace.isEmpty {
            host = "dashscope.aliyuncs.com"
        } else {
            guard workspace.count <= 63,
                  workspace.range(of: #"^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$"#, options: .regularExpression) != nil else { return nil }
            host = "\(workspace.lowercased()).cn-beijing.maas.aliyuncs.com"
        }
        return URL(string: "https://\(host)/\(isBailian ? "compatible-mode/" : "")v1/chat/completions")
    }
}
