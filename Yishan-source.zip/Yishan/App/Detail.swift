import SwiftUI
import Photos

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("screenshotCollectionSince") private var screenshotCollectionSince = 0.0
    @AppStorage("lastScreenshotAutomationRun") private var lastScreenshotAutomationRun = 0.0
    @AppStorage("screenshotAutomationStatus") private var screenshotAutomationStatus = ""
    @AppStorage("automatic") private var automatic = false
    @AppStorage("automaticNotes") private var automaticNotes = false
    @State private var route = VisionRoute.current
    @State private var teamoKey = Credentials.read(for: .teamo)
    @State private var bailianKey = Credentials.read(for: .bailianFlash)
    @AppStorage("bailianWorkspace") private var savedWorkspace = ""
    @State private var workspace = UserDefaults.standard.string(forKey: "bailianWorkspace") ?? ""
    @State private var error: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("截图识别") {
                    Picker("识别通道", selection: $route) {
                        ForEach(VisionRoute.allCases) { Text($0.label).tag($0) }
                    }
                    SecureField(route.isBailian ? "阿里云百炼 API Key" : "TeamoRouter API Key",
                                text: route.isBailian ? $bailianKey : $teamoKey)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    if route.isBailian {
                        TextField("北京业务空间 ID（可选）", text: $workspace)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Text("密钥保存在本机钥匙串。选中的识别服务会收到导入图片及可读取的内嵌元数据。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("截图自动收集") {
                    Toggle("自动收集新截图", isOn: Binding(
                        get: { screenshotCollectionSince > 0 },
                        set: { enabled in
                            if enabled {
                                Task {
                                    let since = Date.now.timeIntervalSince1970
                                    let access = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
                                    if access == .authorized || access == .limited {
                                        screenshotCollectionSince = since
                                        _ = await CaptureNotifications.requestAccess()
                                    } else {
                                        error = "请在 iPhone 设置中允许一闪访问照片。"
                                    }
                                }
                            } else {
                                screenshotCollectionSince = 0
                            }
                        }
                    ))
                    Button("允许摘要通知") {
                        Task {
                            if await !CaptureNotifications.requestAccess(),
                               let url = URL(string: UIApplication.openNotificationSettingsURLString) {
                                await UIApplication.shared.open(url)
                            }
                        }
                    }
                    if let url = URL(string: "shortcuts://") {
                        Link("打开快捷指令", destination: url)
                    }
                    LabeledContent("跨 App 自动化",
                                   value: lastScreenshotAutomationRun > 0
                                    ? Date(timeIntervalSince1970: lastScreenshotAutomationRun).formatted(date: .omitted, time: .standard)
                                    : "尚未触发")
                    if !screenshotAutomationStatus.isEmpty {
                        Text(screenshotAutomationStatus).font(.footnote).foregroundStyle(.secondary)
                    }
                    Text("在「快捷指令 → 自动化」选择「截屏」，保存位置选「照片」，设为「立即运行」，添加一闪的「摘要新截图」。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("系统同步") {
                    Toggle("自动写入日历和提醒事项", isOn: $automatic)
                    Text("识别后，有明确时间的日程会写入日历，待办会写入提醒事项。系统会在首次使用时请求授权。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Apple 备忘录") {
                    Toggle("自动将收藏存入备忘录", isOn: $automaticNotes)
                    Text("在「快捷指令」新建并命名为「一闪存备忘录」，添加「创建备忘录」动作，并将内容设为「快捷指令输入」。启用自动存入后，一批收藏会合并为一条备忘录并打开快捷指令。也可在详情中单独存入。")
                }
            }
            .formStyle(.grouped)
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        do {
                            let space = workspace.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard route.endpoint(workspace: space) != nil else {
                                throw FlashError.message("请输入有效的北京业务空间 ID。")
                            }
                            let key = route.isBailian ? bailianKey : teamoKey
                            if route.isBailian && (key.isEmpty || key.hasPrefix("sk-teamo-")) {
                                throw FlashError.message("请输入阿里云百炼的北京地域 API Key。")
                            }
                            try Credentials.save(key, for: route)
                            savedWorkspace = space
                            UserDefaults.standard.set(route.rawValue, forKey: "visionRoute")
                            dismiss()
                        }
                        catch { self.error = error.localizedDescription }
                    }
                }
            }
            .alert("一闪设置", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("好") { error = nil }
            } message: { Text(error ?? "") }
        }
    }
}

struct CaptureDetail: View {
    @Environment(\.dismiss) private var dismiss
    @State var item: Capture
    var library: Library
    @State private var message: String?
    @State private var working = false
    @State private var deleting = false

    var body: some View {
        Form {
            if let image = library.thumbnail(item.id) {
                Section("截图") {
                    Image(uiImage: image).resizable().scaledToFit()
                        .frame(maxHeight: 340).frame(maxWidth: .infinity)
                        .clipShape(.rect(cornerRadius: 18))
                }
            }
            Section("识别结果") {
                TextField("标题", text: $item.extraction.title)
                TextField("摘要", text: $item.extraction.summary, axis: .vertical).lineLimit(2...6)
                Picker("分类", selection: $item.extraction.category) {
                    ForEach(Category.allCases) { Text($0.rawValue).tag($0) }
                }
                Picker("类型", selection: $item.extraction.kind) {
                    ForEach(Kind.allCases) { Text($0.rawValue).tag($0) }
                }
                if item.extraction.kind != .context {
                    Toggle("设置时间", isOn: Binding(
                        get: { item.extraction.startDate != nil },
                        set: { item.extraction.start = $0 ? dateString(.now) : nil }
                    ))
                    if let start = item.extraction.startDate {
                        DatePicker(item.extraction.kind == .event ? "开始" : "截止", selection: Binding(
                            get: { item.extraction.startDate ?? start },
                            set: { item.extraction.start = dateString($0) }
                        ))
                        if item.extraction.kind == .event {
                            DatePicker("结束", selection: Binding(
                                get: { item.extraction.endDate.flatMap { $0 > start ? $0 : nil } ?? start.addingTimeInterval(3600) },
                                set: { item.extraction.end = dateString($0) }
                            ), in: start...)
                        }
                    }
                }
                TextField("地点", text: Binding(
                    get: { item.extraction.location ?? "" },
                    set: { item.extraction.location = $0.isEmpty ? nil : $0 }
                ))
            }
            if item.extraction.category == .shopping || item.extraction.product != nil {
                Section("商品") {
                    if let product = item.extraction.product {
                        LabeledContent("名称", value: product.name)
                        if let price = product.price { LabeledContent("截图标价", value: price) }
                        if let merchant = product.merchant { LabeledContent("店铺", value: merchant) }
                        if let url = product.webURL { Link("打开商品链接", destination: url) }
                    }
                    Button {
                        var updated = item
                        updated.cartQuantity = 1
                        do {
                            try library.save(updated)
                            item = updated
                        } catch { message = error.localizedDescription }
                    } label: {
                        Label((item.cartQuantity ?? 0) > 0 ? "已加入购物车" : "加入购物车",
                              systemImage: (item.cartQuantity ?? 0) > 0 ? "checkmark" : "cart.badge.plus")
                    }
                    .disabled((item.cartQuantity ?? 0) > 0 || item.extraction.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            if let sourceApp = item.extraction.sourceApp {
                Section("截图来源") {
                    LabeledContent(item.extraction.sourceAppEvidence?.rawValue ?? "来源 App", value: sourceApp)
                }
            }
            if let metadata = item.imageMetadata {
                Section("图片元数据") {
                    DisclosureGroup("查看内嵌字段") {
                        Text(metadata).font(.caption.monospaced()).textSelection(.enabled)
                    }
                }
            }
            Section("存入系统") {
                Button(item.calendarSaved ? "已写入日历" : "存入日历") { export(.event) }
                    .disabled(item.calendarSaved || item.extraction.startDate == nil)
                Button(item.reminderSaved ? "已写入提醒事项" : "存入提醒事项") { export(.task) }
                    .disabled(item.reminderSaved)
            }
            Section("备忘录") {
                ShareLink(item: item.notes) {
                    Label("分享至备忘录", systemImage: "square.and.arrow.up")
                }
                Button {
                    UIPasteboard.general.string = item.notes
                    message = "已复制到剪贴板。可以打开备忘录并粘贴。"
                } label: {
                    Label("复制备忘录文本", systemImage: "document.on.document")
                }
            }
            Section {
                if library.thumbnail(item.id) != nil {
                    Button("只保留文本", role: .destructive) {
                        working = true
                        Task {
                            defer { working = false }
                            do { try await library.keepOnlyText(item) }
                            catch { message = error.localizedDescription }
                        }
                    }
                }
                Button("删除截图记录", role: .destructive) { deleting = true }
            }
        }
        .formStyle(.grouped)
        .disabled(working)
        .navigationTitle("截图详情")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button("保存") {
                do { try save(); dismiss() }
                catch { message = error.localizedDescription }
            }
            .disabled(working)
        }
        .confirmationDialog("删除截图记录？", isPresented: $deleting, titleVisibility: .visible) {
            Button("删除", role: .destructive) {
                do { try library.delete(item); dismiss() }
                catch { message = error.localizedDescription }
            }
        }
        .alert("一闪", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("好") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func dateString(_ date: Date) -> String {
        ISO8601DateFormatter().string(from: date)
    }

    private func save() throws {
        guard !item.extraction.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw FlashError.message("请填写标题。")
        }
        try library.save(item)
    }

    private func export(_ destination: Kind) {
        working = true
        Task {
            defer { working = false }
            do {
                try save()
                switch destination {
                case .event:
                    try await library.destinations.calendar(item)
                    item.calendarSaved = true
                    try save()
                case .task:
                    try await library.destinations.reminder(item)
                    item.reminderSaved = true
                    try save()
                case .context: break
                }
            } catch { message = error.localizedDescription }
        }
    }
}
