import Foundation

enum Category: String, Codable, CaseIterable, Identifiable {
    case work = "工作", food = "美食", fun = "好玩的", life = "生活", shopping = "购物", other = "其他"
    var id: String { rawValue }
}

enum Kind: String, Codable, CaseIterable, Identifiable {
    case event = "日程", task = "待办", context = "收藏"
    var id: String { rawValue }
}

struct Product: Codable {
    var name: String
    var price: String?
    var merchant: String?
    var link: String?

    var webURL: URL? {
        guard let link, let url = URL(string: link),
              let scheme = url.scheme?.lowercased(), ["https", "http"].contains(scheme),
              let host = url.host, !host.isEmpty else { return nil }
        return url
    }
}

struct Extraction: Codable {
    var title: String
    var summary: String
    var category: Category
    var kind: Kind
    var start: String?
    var end: String?
    var location: String?
    var sourceApp: String?
    var sourceAppEvidence: AppEvidence?
    var product: Product?

    enum AppEvidence: String, Codable {
        case metadata = "图片元数据"
        case appearance = "画面推断"
    }

    var startDate: Date? { Self.parseDate(start) }
    var endDate: Date? { Self.parseDate(end) }

    static func parseDate(_ value: String?) -> Date? {
        value.flatMap { ISO8601DateFormatter().date(from: $0) }
    }
}

struct Capture: Codable, Identifiable {
    var id = UUID()
    var created = Date()
    var extraction: Extraction
    var imageMetadata: String?
    var photoAssetID: String?
    var cartQuantity: Int?
    var usedLocalText: Bool?
    var calendarSaved = false
    var reminderSaved = false

    static func exportContext(_ captures: [Capture]) -> String {
        let date = ISO8601DateFormatter()
        let records = captures.enumerated().map { index, capture in
            let item = capture.extraction
            var lines = [
                "## \(index + 1). \(item.title)",
                "摘要：\(item.summary)",
                "分类：\(item.category.rawValue)",
                "类型：\(item.kind.rawValue)",
                "收录时间：\(date.string(from: capture.created))"
            ]
            if let start = item.start { lines.append("\(item.kind == .task ? "截止时间" : "开始时间")：\(start)") }
            if let end = item.end { lines.append("结束时间：\(end)") }
            if let location = item.location { lines.append("地点：\(location)") }
            if let app = item.sourceApp {
                lines.append("来源 App：\(app)（\(item.sourceAppEvidence?.rawValue ?? "依据未记录")）")
            }
            if let product = item.product {
                lines.append("商品：\(product.name)")
                if let price = product.price { lines.append("截图标价：\(price)") }
                if let merchant = product.merchant { lines.append("店铺：\(merchant)") }
                if let url = product.webURL { lines.append("商品链接：\(url.absoluteString)") }
            }
            if let quantity = capture.cartQuantity, quantity > 0 { lines.append("购物车数量：\(quantity)") }
            if capture.calendarSaved { lines.append("已写入日历") }
            if capture.reminderSaved { lines.append("已写入提醒事项") }
            if let metadata = capture.imageMetadata { lines.append("图片内嵌元数据：\n\(metadata)") }
            return lines.joined(separator: "\n")
        }
        return ([
            "# 一闪图片库上下文",
            "共 \(captures.count) 条记录。以下内容来自图片与元数据，可作为分析和拟定行动的资料。"
        ] + records).joined(separator: "\n\n")
    }

    var notes: String {
        [extraction.title, extraction.summary, extraction.location, extraction.sourceApp, extraction.product?.name, extraction.product?.merchant].compactMap { $0 }.joined(separator: "\n")
    }
}

enum ScreenshotStatusBar {
    static func isStatusText(_ text: String, centerX: Double, topY: Double) -> Bool {
        guard topY >= 0.94 else { return false }
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if centerX < 0.40 {
            return value.range(of: #"^(?:[01]?\d|2[0-3])[:：][0-5]\d\d?$"#, options: .regularExpression) != nil
        }
        if centerX > 0.60 {
            return value.range(of: #"^(?:100|\d{1,2})\s*[%％]?$|^(?:[345]G|LTE|Wi[- ]?Fi)$"#,
                               options: [.regularExpression, .caseInsensitive]) != nil
        }
        return false
    }
}
