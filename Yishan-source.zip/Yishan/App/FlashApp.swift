import SwiftUI
import PhotosUI
import Photos

@main struct FlashApp: App {
    @UIApplicationDelegateAdaptor(CaptureNotifications.self) private var notifications
    var body: some Scene {
        WindowGroup { LibraryView(library: notifications.library).environment(\.locale, Locale(identifier: "zh_CN")) }
    }
}

@MainActor @Observable final class Library {
    static let shared = Library()
    @ObservationIgnored var collectingAssets: Set<String> = []
    var items: [Capture] = []
    let folder = URL.documentsDirectory.appending(path: "Captures")
    let destinations = SystemDestinations()
    var error: String?
    @ObservationIgnored private var index: URL { folder.appending(path: "index.json") }

    init() {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: index.path) {
                items = try JSONDecoder().decode([Capture].self, from: Data(contentsOf: index))
            }
        } catch { self.error = error.localizedDescription }
    }

    func image(_ id: UUID) -> URL { folder.appending(path: id.uuidString + ".jpg") }

    func save(_ item: Capture, photo: Data? = nil) throws {
        var next = items
        if let position = next.firstIndex(where: { $0.id == item.id }) { next[position] = item }
        else { next.insert(item, at: 0) }
        if let photo { try photo.write(to: image(item.id), options: .atomic) }
        try JSONEncoder().encode(next).write(to: index, options: .atomic)
        items = next
    }

    private var imageRemovals: Set<UUID> = []

    func keepOnlyText(_ item: Capture) async throws {
        guard imageRemovals.insert(item.id).inserted else { return }
        defer { imageRemovals.remove(item.id) }

        guard let assetID = item.photoAssetID else {
            throw FlashError.message("这条旧记录没有关联相册原图。请在系统相册中删除原图。")
        }
        let access = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
        guard access == .authorized || access == .limited else {
            throw FlashError.message("请在 iPhone 设置中允许一闪访问照片后再试。")
        }

        let assets = PHAsset.fetchAssets(withLocalIdentifiers: [assetID], options: nil)
        if assets.count > 0 {
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.deleteAssets(assets)
                }
            } catch let error as PHPhotosError where error.code == .userCancelled {
                return
            }
        } else if access == .limited {
            throw FlashError.message("这张原图不在一闪可访问的照片中。请在 iPhone 设置中允许访问该照片后再试。")
        }

        try removeImage(item.id)
    }

    private func removeImage(_ id: UUID) throws {
        let url = image(id)
        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        // Refresh visible cards and any open detail after the image is removed.
        imageRevision += 1
    }

    private(set) var imageRevision = 0

    func thumbnail(_ id: UUID) -> UIImage? {
        _ = imageRevision
        return UIImage(contentsOfFile: image(id).path)
    }

    func delete(_ item: Capture) throws {
        if let id = item.photoAssetID {
            let defaults = UserDefaults.standard
            var ignored = Set(defaults.stringArray(forKey: "deletedPhotoAssetIDs") ?? [])
            ignored.insert(id)
            defaults.set(Array(ignored), forKey: "deletedPhotoAssetIDs")
        }
        let next = items.filter { $0.id != item.id }
        try JSONEncoder().encode(next).write(to: index, options: .atomic)
        items = next
        try? FileManager.default.removeItem(at: image(item.id))
    }
}

private struct PendingCapture: Identifiable {
    let id = UUID()
    let image: UIImage
    var failure: String?
}

private enum ImportImage {
    case selected(PhotosPickerItem)
    case screenshot(PHAsset)

    var assetID: String? {
        switch self {
        case .selected(let item): item.itemIdentifier
        case .screenshot(let asset): asset.localIdentifier
        }
    }

    var isScreenshot: Bool {
        if automatic { return true }
        guard let assetID else { return false }
        return PHAsset.fetchAssets(withLocalIdentifiers: [assetID], options: nil)
            .firstObject?.mediaSubtypes.contains(.photoScreenshot) == true
    }

    var automatic: Bool {
        if case .screenshot = self { return true }
        return false
    }

    func data() async throws -> Data? {
        switch self {
        case .selected(let item): try await item.loadTransferable(type: Data.self)
        case .screenshot(let asset): try await ScreenshotObserver.data(for: asset)
        }
    }
}

struct RecognitionInput: Sendable {
    let index: Int
    let id: UUID
    let request: Data
    let preview: Data
    let metadata: String?
    let assetID: String?
    let automaticallyCollected: Bool

    func recognize(key: String, route: VisionRoute) async throws -> (Extraction, Bool) {
        let local = try? VisionService.readText(request)
        do {
            guard !key.isEmpty else { throw FlashError.message("请在设置中填写识别通道的 API Key") }
            return (try await VisionService.extract(request, metadata: metadata, localText: local?.summary, key: key, route: route), false)
        } catch {
            if let local { return (local, true) }
            throw error
        }
    }
}

struct LibraryView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var screenshotObserver = ScreenshotObserver()
    @State private var photoLibraryChangedWhileBusy = false
    @AppStorage("screenshotCollectionSince") private var screenshotCollectionSince = 0.0
    let library: Library
    @State private var selected: [PhotosPickerItem] = []
    @State private var pending: [PendingCapture] = []
    @State private var busy = false
    @State private var status = ""
    @State private var screenshotNotice: UUID?
    @State private var showSettings = false
    @State private var showCart = false
    @State private var copiedContext = false
    @AppStorage("askedForSummaryNotifications") private var askedForSummaryNotifications = false
    @State private var category: Category?
    @State private var grid = false
    @State private var query = ""
    @AppStorage("automatic") private var automatic = false
    @AppStorage("automaticNotes") private var automaticNotes = false

    private var visible: [Capture] {
        library.items.filter {
            (category == nil || $0.extraction.category == category) &&
            (query.isEmpty || $0.notes.localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    filters
                    if visible.isEmpty && pending.isEmpty {
                        ContentUnavailableView(
                            library.items.isEmpty ? "还没有截图" : "没有匹配的截图",
                            systemImage: "square.on.square",
                            description: Text(library.items.isEmpty ? "从相册导入你想记住的截图。" : "试试其他分类或关键词。")
                        )
                        .frame(maxWidth: .infinity, minHeight: 280)
                    } else {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: grid ? 3 : 2), alignment: .leading, spacing: 14) {
                            ForEach(pending.map(\.id) + visible.filter { item in !pending.contains { $0.id == item.id } }.map(\.id), id: \.self) { id in
                                if let draft = pending.first(where: { $0.id == id }) {
                                    CaptureCard(item: nil, image: draft.image, compact: grid, failure: draft.failure)
                                        .contextMenu {
                                            if draft.failure != nil {
                                                Button("移除", role: .destructive) { pending.removeAll { $0.id == id } }
                                            }
                                        }
                                } else if let item = visible.first(where: { $0.id == id }) {
                                    NavigationLink {
                                        CaptureDetail(item: item, library: library)
                                    } label: {
                                        CaptureCard(item: item, image: library.thumbnail(id), compact: grid)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("图片库")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索图片")
            .toolbar { libraryToolbar }
            .overlay(alignment: .bottom) {
                if busy {
                    HStack(spacing: 8) {
                        ProgressView().controlSize(.small)
                        Text(status).font(.footnote)
                    }
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(.regularMaterial, in: Capsule())
                    .padding(.bottom, 8)
                    .allowsHitTesting(false)
                }
            }
        }
        .overlay(alignment: .top) {
            if screenshotNotice != nil {
                HStack(spacing: 9) {
                    ProgressView().controlSize(.small)
                    Text("正在摘要").font(.subheadline.weight(.semibold))
                }
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(.regularMaterial, in: Capsule())
                .padding(.top, 8)
                .allowsHitTesting(false)
                .accessibilityIdentifier("screenshot-summary-notice")
            }
        }
        .task(id: screenshotNotice) {
            guard screenshotNotice != nil else { return }
            try? await Task.sleep(for: .seconds(2.5))
            if !Task.isCancelled { screenshotNotice = nil }
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCart) { ShoppingCartView(library: library) }
        .alert("一闪", isPresented: Binding(
            get: { library.error != nil },
            set: { if !$0 { library.error = nil } }
        )) { Button("好") { library.error = nil } } message: { Text(library.error ?? "") }
        .onChange(of: selected) { _, images in
            guard !images.isEmpty, !busy else { return }
            busy = true
            category = nil
            query = ""
            status = "读取截图"
            Task { await importImages(images.map(ImportImage.selected)) }
        }
        .onChange(of: screenshotCollectionSince, initial: true) {
            screenshotObserver.setEnabled(screenshotCollectionSince > 0)
            collectScreenshots()
        }
        .onChange(of: scenePhase) {
            if scenePhase == .active { collectScreenshots() }
        }
        .onChange(of: screenshotObserver.revision) { collectScreenshots() }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.userDidTakeScreenshotNotification)) { _ in
            guard scenePhase == .active, screenshotCollectionSince > 0 else { return }
            screenshotNotice = UUID()
            Task { await CaptureNotifications.deliverImport(count: 1) }
            collectScreenshots()
        }
        .onChange(of: busy) {
            if !busy, photoLibraryChangedWhileBusy {
                photoLibraryChangedWhileBusy = false
                collectScreenshots()
            }
        }
    }

    @ToolbarContentBuilder
    private var libraryToolbar: some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button {
                UIPasteboard.general.string = Capture.exportContext(library.items)
                copiedContext = true
            } label: {
                Label("复制给 AI", systemImage: "document.on.document")
            }
            .disabled(library.items.isEmpty)
            .alert("已复制上下文", isPresented: $copiedContext) {
                Button("好", role: .cancel) {}
            } message: {
                Text("已复制全部 \(library.items.count) 条记录，可粘贴给 AI。")
            }

            Button { showCart = true } label: {
                Label("购物车", systemImage: "cart")
            }

            Button {
                showSettings = true
            } label: {
                Label("设置", systemImage: "gearshape")
            }
        }
        ToolbarItemGroup(placement: .bottomBar) {
            Button {
                grid.toggle()
            } label: {
                Label(grid ? "切换卡片视图" : "切换网格视图",
                      systemImage: grid ? "rectangle.grid.2x2" : "square.grid.3x3")
            }
            Spacer()
            PhotosPicker(selection: $selected, maxSelectionCount: 12, matching: .images, preferredItemEncoding: .current, photoLibrary: .shared()) {
                Label("导入截图", systemImage: "plus")
            }
            .tint(.accentColor)
            .disabled(busy)
        }
    }

    private var filters: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                chip("全部", value: nil)
                ForEach(Category.allCases) { chip($0.rawValue, value: $0) }
            }
        }
        .scrollIndicators(.hidden)
    }

    private func chip(_ title: String, value: Category?) -> some View {
        Button {
            category = value
        } label: {
            Text(title)
                .font(.subheadline.weight(.medium))
                .fixedSize()
                .padding(.horizontal, 4)
        }
        .buttonStyle(.bordered)
        .buttonBorderShape(.capsule)
        .tint(category == value ? .accentColor : .secondary)
        .accessibilityAddTraits(category == value ? .isSelected : [])
    }

    private func collectScreenshots() {
        guard screenshotCollectionSince > 0, scenePhase == .active else { return }
        guard !busy else { photoLibraryChangedWhileBusy = true; return }
        let existing = Set(library.items.compactMap(\.photoAssetID))
        let deleted = Set(UserDefaults.standard.stringArray(forKey: "deletedPhotoAssetIDs") ?? [])
        let unseen = ScreenshotObserver.screenshots(since: Date(timeIntervalSince1970: screenshotCollectionSince))
            .filter { !existing.contains($0.localIdentifier) && !deleted.contains($0.localIdentifier) && !library.collectingAssets.contains($0.localIdentifier) }
        guard !unseen.isEmpty else { return }
        busy = true
        category = nil
        query = ""
        status = "正在摘要"
        screenshotNotice = UUID()
        let ids = unseen.map(\.localIdentifier)
        library.collectingAssets.formUnion(ids)
        Task {
            defer { library.collectingAssets.subtract(ids) }
            await CaptureNotifications.deliverImport(count: unseen.count)
            await importImages(unseen.map(ImportImage.screenshot))
        }
    }

    private func importImages(_ images: [ImportImage]) async {
        defer { selected = []; busy = false }
        let route = VisionRoute.current
        let key = Credentials.read(for: route)
        guard !key.isEmpty || images.first?.automatic == true else { showSettings = true; return }
        if !askedForSummaryNotifications {
            askedForSummaryNotifications = true
            _ = await CaptureNotifications.requestAccess()
        }
        var failures: [String] = []
        var notes: [String] = []
        var prepared: [RecognitionInput] = []
        for (index, image) in images.enumerated() {
            do {
                guard let data = try await image.data(),
                      let requestImage = VisionService.jpeg(data, size: 1560, hideStatusBar: image.isScreenshot),
                      let preview = VisionService.jpeg(data, size: 850),
                      let thumbnail = UIImage(data: preview) else {
                    throw FlashError.message("无法读取图片")
                }
                let draft = PendingCapture(image: thumbnail)
                let metadata = VisionService.metadata(from: data)
                if image.automatic {
                    let placeholder = Capture(id: draft.id, extraction: Extraction(
                        title: "新截图", summary: "等待摘要", category: .other, kind: .context
                    ), imageMetadata: metadata, photoAssetID: image.assetID)
                    try library.save(placeholder, photo: preview)
                }
                pending.append(draft)
                prepared.append(RecognitionInput(index: index, id: draft.id, request: requestImage, preview: preview,
                                                metadata: metadata, assetID: image.assetID, automaticallyCollected: image.automatic))
            } catch { failures.append("第 \(index + 1) 张：\(error.localizedDescription)") }
        }
        if !prepared.isEmpty, images.first?.automatic == false { await CaptureNotifications.deliverImport(count: prepared.count) }
        let limit = 3
        await withTaskGroup(of: (RecognitionInput, Result<(Extraction, Bool), Error>).self) { group in
            var queue = prepared.makeIterator()
            for _ in 0..<limit {
                guard let photo = queue.next() else { break }
                group.addTask {
                    do { return (photo, .success(try await photo.recognize(key: key, route: route))) }
                    catch { return (photo, .failure(error)) }
                }
            }
            var completed = 0
            while let (photo, result) = await group.next() {
                if let next = queue.next() {
                    group.addTask {
                        do { return (next, .success(try await next.recognize(key: key, route: route))) }
                        catch { return (next, .failure(error)) }
                    }
                }
                completed += 1
                status = "摘要 \(completed)/\(prepared.count)"
                    do {
                        let (extraction, usedLocalText) = try result.get()
                        var capture = Capture(id: photo.id, extraction: extraction, imageMetadata: photo.metadata, photoAssetID: photo.assetID, usedLocalText: usedLocalText ? true : nil)
                        try library.save(capture, photo: photo.preview)
                        pending.removeAll { $0.id == photo.id }
                        await CaptureNotifications.deliver(capture, usedLocalText: usedLocalText)
                        guard !usedLocalText else { continue }
                        if automaticNotes, capture.extraction.kind == .context { notes.append(capture.notes) }
                        if automatic {
                            switch capture.extraction.kind {
                            case .event where capture.extraction.startDate != nil:
                                try await library.destinations.calendar(capture)
                                capture.calendarSaved = true
                                try library.save(capture)
                            case .task:
                                try await library.destinations.reminder(capture)
                                capture.reminderSaved = true
                                try library.save(capture)
                            default: break
                            }
                        }
                    } catch {
                        let message = (error as? URLError)?.code == .secureConnectionFailed
                            ? "无法安全连接识别服务" : error.localizedDescription
                        if photo.automaticallyCollected, var capture = library.items.first(where: { $0.id == photo.id }),
                           pending.contains(where: { $0.id == photo.id }) {
                            capture.extraction.summary = "摘要失败 · " + message
                            do { try library.save(capture) }
                            catch { failures.append(error.localizedDescription) }
                            pending.removeAll { $0.id == photo.id }
                        } else if let draftIndex = pending.firstIndex(where: { $0.id == photo.id }) {
                            pending[draftIndex].failure = message
                        } else {
                            failures.append("第 \(photo.index + 1) 张：\(message)")
                        }
                    }
            }
        }
        if !notes.isEmpty {
            do { try await library.destinations.openNotesShortcut(notes.joined(separator: "\n\n")) }
            catch { failures.append(error.localizedDescription) }
        }
        if !failures.isEmpty { library.error = failures.joined(separator: "\n") }
    }
}

struct CaptureCard: View {
    let item: Capture?
    let image: UIImage?
    let compact: Bool
    var failure: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            if let image {
                Color(uiColor: .tertiarySystemFill)
                    .overlay { Image(uiImage: image).resizable().scaledToFill() }
                    .frame(height: compact ? 104 : 132)
                    .clipShape(.rect(cornerRadius: compact ? 15 : 20))
                    .accessibilityHidden(true)
            }
            if let item {
                Text(item.usedLocalText == true ? "设备文字识别" : item.extraction.category.rawValue + " · " + item.extraction.kind.rawValue)
                    .font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                Text(item.extraction.title).font(.subheadline.bold()).lineLimit(2)
                if !compact {
                    Text(item.extraction.summary).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                    Text(item.created.formatted(.dateTime.month().day())).font(.caption2).foregroundStyle(.secondary)
                }
            } else if let failure {
                Label("摘要失败", systemImage: "exclamationmark.circle")
                    .font(.caption.weight(.semibold)).foregroundStyle(.orange)
                Text(failure).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
            } else {
                HStack(spacing: 7) {
                    ProgressView().controlSize(.small).accessibilityHidden(true)
                    Text("正在摘要").font(.caption.weight(.medium)).foregroundStyle(.secondary)
                }
                if !compact {
                    VStack(alignment: .leading, spacing: 5) {
                        Capsule().frame(width: 84, height: 6)
                        Capsule().frame(width: 57, height: 6)
                    }
                    .foregroundStyle(.quaternary)
                    .accessibilityHidden(true)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .padding(compact ? 7 : 10)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: .rect(cornerRadius: compact ? 18 : 24))
    }
}
