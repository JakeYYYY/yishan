import UIKit
import UserNotifications

final class CaptureNotifications: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    private static let category = "capture.summary"
    private static let copy = "capture.copy"
    private static let remove = "capture.remove-image"
    @MainActor var library: Library { .shared }
    @MainActor private static var lastImportNotice: Date?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.setNotificationCategories([UNNotificationCategory(
            identifier: Self.category,
            actions: [
                UNNotificationAction(identifier: Self.remove, title: "只保留文本", options: [.destructive, .foreground]),
                UNNotificationAction(identifier: Self.copy, title: "复制文本", options: [.foreground])
            ], intentIdentifiers: [], options: []
        )])
        return true
    }

    static func requestAccess() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert])) == true
    }

    @discardableResult @MainActor static func deliverImport(count: Int) async -> Bool {
        let now = Date()
        if let last = lastImportNotice, now.timeIntervalSince(last) < 1.5 { return true }
        let content = UNMutableNotificationContent()
        content.title = "正在摘要"
        content.body = count == 1 ? "正在处理新截图" : "正在处理 \(count) 张截图"
        let scheduled = await schedule(content, id: UUID().uuidString)
        if scheduled { lastImportNotice = now }
        return scheduled
    }

    static func deliver(_ capture: Capture, usedLocalText: Bool) async {
        let content = UNMutableNotificationContent()
        content.title = usedLocalText ? "截图文字已提取" : "截图摘要已就绪"
        content.body = capture.extraction.title
        content.categoryIdentifier = category
        content.userInfo = ["capture": capture.id.uuidString]
        _ = await schedule(content, id: capture.id.uuidString)
    }

    private static func schedule(_ content: UNMutableNotificationContent, id: String) async -> Bool {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return false }
        do {
            try await center.add(UNNotificationRequest(identifier: id, content: content, trigger: nil))
            return true
        } catch {
            return false
        }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions {
        [.banner, .list]
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse) async {
        guard let value = response.notification.request.content.userInfo["capture"] as? String,
              let id = UUID(uuidString: value) else { return }
        let action = response.actionIdentifier
        await handle(action, id: id)
    }

    @MainActor private func handle(_ action: String, id: UUID) async {
        guard let capture = library.items.first(where: { $0.id == id }) else { return }
        switch action {
        case Self.copy:
            UIPasteboard.general.string = capture.notes
        case Self.remove:
            do { try await library.keepOnlyText(capture) }
            catch { library.error = error.localizedDescription }
        default: break
        }
    }
}
