import AppIntents
import Photos

struct SummarizeScreenshotIntent: AppIntent {
    static let title: LocalizedStringResource = "摘要新截图"
    static let description = IntentDescription("在系统保存截图后显示通知，并在后台整理截图。")
    static let openAppWhenRun = false
    @available(iOS 26, *)
    static var supportedModes: IntentModes { .background }

    @MainActor
    func perform() async throws -> some IntentResult {
        let defaults = UserDefaults.standard
        defaults.set(Date.now.timeIntervalSince1970, forKey: "lastScreenshotAutomationRun")
        let since = defaults.double(forKey: "screenshotCollectionSince")
        guard since > 0 else {
            defaults.set("自动收集尚未开启", forKey: "screenshotAutomationStatus")
            throw FlashError.message("请先在一闪开启自动收集新截图。")
        }
        let library = Library.shared
        let ignored = Set(defaults.stringArray(forKey: "deletedPhotoAssetIDs") ?? [])
        let cutoff = max(Date(timeIntervalSince1970: since), Date().addingTimeInterval(-120))
        var candidate: PHAsset?
        for attempt in 0..<5 {
            let recorded = Set(library.items.compactMap(\.photoAssetID))
            let latest = ScreenshotObserver.screenshots(since: cutoff).last
            if let latest {
                let id = latest.localIdentifier
                if recorded.contains(id) || ignored.contains(id) || !library.collectingAssets.insert(id).inserted {
                    defaults.set("最近一张截图已由一闪接收", forKey: "screenshotAutomationStatus")
                    return .result()
                }
                candidate = latest
                break
            }
            if attempt < 4 { try await Task.sleep(for: .milliseconds(250)) }
        }
        guard let asset = candidate else {
            defaults.set("已触发，但没有读到新截图。请检查照片访问权限。", forKey: "screenshotAutomationStatus")
            return .result()
        }
        defer { library.collectingAssets.remove(asset.localIdentifier) }

        let notice = await CaptureNotifications.deliverImport(count: 1)
        defaults.set(notice ? "已提交「正在摘要」通知" : "系统未接受「正在摘要」通知，请检查通知权限", forKey: "screenshotAutomationStatus")
        let data = try await ScreenshotObserver.data(for: asset)
        guard let image = VisionService.jpeg(data, size: 1560, hideStatusBar: true),
              let preview = VisionService.jpeg(data, size: 850) else {
            throw FlashError.message("无法读取相册截图。")
        }
        let route = VisionRoute.current
        let input = RecognitionInput(index: 0, id: UUID(), request: image, preview: preview,
                                     metadata: VisionService.metadata(from: data),
                                     assetID: asset.localIdentifier, automaticallyCollected: true)
        do {
            let (text, local) = try await input.recognize(key: Credentials.read(for: route), route: route)
            let capture = Capture(id: input.id, extraction: text, imageMetadata: input.metadata,
                                  photoAssetID: input.assetID, usedLocalText: local ? true : nil)
            try library.save(capture, photo: preview)
            await CaptureNotifications.deliver(capture, usedLocalText: local)
        } catch {
            let failed = Capture(id: input.id,
                                 extraction: Extraction(title: "新截图", summary: "摘要失败 · " + error.localizedDescription,
                                                        category: .other, kind: .context),
                                 imageMetadata: input.metadata, photoAssetID: input.assetID)
            try library.save(failed, photo: preview)
            throw error
        }
        return .result()
    }
}

struct FlashShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: SummarizeScreenshotIntent(),
                    phrases: ["用\(.applicationName)摘要新截图"],
                    shortTitle: "摘要新截图", systemImageName: "text.viewfinder")
    }
}
