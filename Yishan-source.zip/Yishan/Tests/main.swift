import Foundation

let payload = #"{"title":"设计评审","summary":"准备首页方案","category":"工作","kind":"日程","start":null,"end":null,"location":null}"#
let item = try JSONDecoder().decode(Extraction.self, from: Data(payload.utf8))
precondition(item.category == .work)
precondition(item.kind == .event)
precondition(item.startDate == nil)
precondition(Extraction.parseDate("2026-11-21T15:00:00+08:00") != nil)
precondition(Extraction.parseDate("2026-11-21") == nil)
print("Extraction checks passed")

let attachment = Capture(extraction: item, imageMetadata: #"{"GPS":{"Latitude":31.23}}"#)
let context = Capture.exportContext([attachment])
precondition(context.contains("设计评审"))
precondition(context.contains("准备首页方案"))
precondition(context.contains("31.23"))
precondition(context.contains("工作"))
print("Context export checks passed")

let productJSON = #"{"title":"旅行杯","summary":"不锈钢保温杯","category":"购物","kind":"收藏","product":{"name":"旅行杯","price":"¥129","merchant":"示例店","link":"https://example.com/item"}}"#
let product = try JSONDecoder().decode(Extraction.self, from: Data(productJSON.utf8))
precondition(product.category == .shopping)
precondition(product.product?.webURL?.host == "example.com")
precondition(Product(name: "测试", link: "javascript:alert(1)").webURL == nil)
let cartItem = Capture(extraction: product, cartQuantity: 2)
precondition(Capture.exportContext([cartItem]).contains("购物车数量：2"))
print("Shopping checks passed")

precondition(VisionRoute.bailianFlash.endpoint(workspace: "")?.host == "dashscope.aliyuncs.com")
precondition(VisionRoute.bailianMax.endpoint(workspace: "llm-demo")?.host == "llm-demo.cn-beijing.maas.aliyuncs.com")
precondition(VisionRoute.bailianMax.endpoint(workspace: "example.com/path") == nil)
precondition(VisionRoute.teamo.endpoint(workspace: "llm-demo")?.host == "api.teamorouter.com")
print("Vision routing checks passed")

precondition(ScreenshotStatusBar.isStatusText("00:534", centerX: 0.16, topY: 0.97))
precondition(ScreenshotStatusBar.isStatusText("90", centerX: 0.88, topY: 0.97))
precondition(ScreenshotStatusBar.isStatusText("90%", centerX: 0.88, topY: 0.97))
precondition(!ScreenshotStatusBar.isStatusText("15:00", centerX: 0.16, topY: 0.55))
precondition(!ScreenshotStatusBar.isStatusText("90", centerX: 0.88, topY: 0.65))
print("Screenshot status-bar checks passed")
