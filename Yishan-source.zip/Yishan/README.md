# Yishan 一闪

Yishan is a SwiftUI app that turns iPhone screenshots into a searchable library of notes, tasks, and events. It uses Apple Vision for on-device OCR and optionally connects to TeamoRouter or Alibaba Cloud Bailian for structured extraction.

[Project website](https://jakeyyyy.github.io/yishan/) · [Local site source](docs/index.html) · [15-second walkthrough](docs/media/walkthrough.mp4)

## Build and run

1. Open `Flash.xcodeproj` in Xcode and select the `Flash` scheme.
2. Choose an iPhone simulator and run. The deployment target is iOS 17. Use an Xcode SDK that includes the iOS 26 App Intents APIs.
3. To run on a physical device, select your signing team and use an available bundle identifier.
4. Tap **+** to import images. For cloud recognition, select a provider in Settings and enter your own API key.

The app interface is in Chinese. The [English guide](docs/index.html) covers import, search, Calendar and Reminders export, optional Shortcuts automation, and how the app handles your data.

## Project files

| Path | Contents |
| --- | --- |
| `App/` | SwiftUI app, image recognition, storage, and system integrations |
| `Flash.xcodeproj/` | Xcode project |
| `Tests/` | Standalone Swift checks |
| `Preview/` | App screenshots from development |
| `docs/` | GitHub Pages site, screenshots, and captioned walkthrough |

Run the standalone checks on macOS from the repository root.

```sh
swiftc App/Extraction.swift App/VisionRoute.swift Tests/main.swift -o /tmp/yishan-checks
/tmp/yishan-checks
```
